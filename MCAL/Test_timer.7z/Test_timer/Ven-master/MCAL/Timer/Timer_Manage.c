/*
 * Timer_Manage.c
 *
 *  Created on: May 15, 2020
 *      Author: Ahmed_Saad
 */
#include <stdbool.h>
#include <stdint.h>
#include "inc/hw_ints.h"
#include "driverlib/sysctl.h"
#include "inc/hw_memmap.h"
#include "inc/hw_timer.h"
#include "inc/hw_types.h"
#include "inc/hw_sysctl.h"
#include "driverlib/debug.h"
#include "driverlib/interrupt.h"
#include "driverlib/timer.h"
#include "Timer_Manage.h"
#include "PWM/PWM.h"
#include "pwm.h"

#define TIMER_PRESCALER (uint32_t)255
#define TIMER_LOAD_VALUE (uint32_t)65535

static uint8_t counter=0;
static uint8_t flag=0;


static void Timer_vidISRHandler(void)
{
    counter++;
    if(counter>5)
    {
        counter=0;
        if(flag==1)
        {
            flag=0;
            PWMPulseWidthSet(PWM1_BASE, PWM_OUT_5,(90*PWM_PERIOD)/100);
        }else if(flag==0)
        {
            flag=1;
            PWMPulseWidthSet(PWM1_BASE, PWM_OUT_5, (0*PWM_PERIOD)/100 );
        }
    }
    TimerIntClear(TIMER0_BASE,TIMER_TIMA_TIMEOUT);
}



void TimervidInit(void)
{

    //enable Timer0 module 0
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);

    //reset module
    SysCtlPeripheralReset(SYSCTL_PERIPH_TIMER0);

    /* Configure time in periodic */
    TimerConfigure(TIMER0_BASE,(TIMER_CFG_A_ACT_TOINTD|TIMER_CFG_A_PERIODIC_UP|TIMER_CFG_SPLIT_PAIR));

  //  TimerConfigure(TIMER0_BASE,(0x12|TIMER_CFG_SPLIT_PAIR));

    /*Set pre-scale 32*/
    TimerPrescaleSet(TIMER0_BASE,TIMER_A,TIMER_PRESCALER);
    /* Time period 25000 tick, time = 25000 * ( 32 / 80 * 10^6 )*/
    TimerLoadSet(TIMER0_BASE,TIMER_A,TIMER_LOAD_VALUE);
    /* Set ISR handler with function Timer_vidISRHandler */
    TimerIntRegister(TIMER0_BASE,TIMER_A,Timer_vidISRHandler);
    /* Enable interrupt in interrupt peripheral*/
    IntEnable(INT_TIMER0A);
    /*Enable interrupt in timer peripheral*/
    TimerIntEnable(TIMER0_BASE,TIMER_TIMA_TIMEOUT);
    /* Enable timer */
    TimerEnable(TIMER0_BASE,TIMER_A);
}
