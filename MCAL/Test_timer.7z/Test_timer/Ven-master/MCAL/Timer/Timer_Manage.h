/*
 * Timer_Manage.h
 *
 *  Created on: May 15, 2020
 *      Author: Ahmed_Saad
 */

#ifndef MCAL_TIMER_TIMER_MANAGE_H_
#define MCAL_TIMER_TIMER_MANAGE_H_


void TimervidInit(void);


#endif /* MCAL_TIMER_TIMER_MANAGE_H_ */
