/*
 * PWM.c
 *
 *  Created on: May 15, 2020
 *      Author: m7mod
 */

#include "driverlib/pin_map.h"
#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_gpio.h"
#include "inc/hw_types.h"
#include "inc/hw_memmap.h"
#include "driverlib/sysctl.h"
#include "driverlib/pin_map.h"
#include "driverlib/gpio.h"
#include "driverlib/pwm.h"
#include"PWM.h"


uint8_t InitPwmChannel(uint8_t ui8Port, uint8_t ui8PinNumber,uint8_t ui8Pwm )
{
    SysCtlPWMClockSet(PWM_CLOCK);
    uint8_t ui8Error=0;
    switch (ui8Port) {
    case PORTA:
    {
        SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
        switch (ui8PinNumber) {
        case 6:
            GPIOPinConfigure(GPIO_PA6_M1PWM2);
            SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM1);
            PWMGenConfigure(PWM1_BASE, PWM_GEN_1, PWM_GEN_MODE_DOWN | PWM_GEN_MODE_NO_SYNC);
            //Set the Period (expressed in clock ticks)
            PWMGenPeriodSet(PWM1_BASE, PWM_GEN_1, PWM_PERIOD);
            //Set PWM duty-50% (Period /2)
            PWMPulseWidthSet(PWM1_BASE, PWM_OUT_2, (ui8Pwm*PWM_PERIOD)/100 );
            // Enable the PWM generator
            PWMGenEnable(PWM1_BASE, PWM_GEN_1);
            // Turn on the Output pins
            PWMOutputState(PWM1_BASE, PWM_OUT_2_BIT, true);
            break;
        case 7:
            GPIOPinConfigure(GPIO_PA7_M1PWM3);
            SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM1);
            PWMGenConfigure(PWM1_BASE, PWM_GEN_1, PWM_GEN_MODE_DOWN | PWM_GEN_MODE_NO_SYNC);

            //Set the Period (expressed in clock ticks)
            PWMGenPeriodSet(PWM1_BASE, PWM_GEN_1, PWM_PERIOD);
            //Set PWM duty-50% (Period /2)
            PWMPulseWidthSet(PWM1_BASE, PWM_OUT_3, (ui8Pwm*PWM_PERIOD)/100 );
            // Enable the PWM generator
            PWMGenEnable(PWM1_BASE, PWM_GEN_1);
            // Turn on the Output pins
            PWMOutputState(PWM1_BASE, PWM_OUT_3_BIT, true);
            break;
        default:
            ui8Error=1;
            break;
        }
    }
    break;
    case PORTB:
    {
        SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
        switch (ui8PinNumber) {
        case 4:
            GPIOPinConfigure(GPIO_PB4_M0PWM2);
            SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM0);
            PWMGenConfigure(PWM0_BASE, PWM_GEN_1, PWM_GEN_MODE_DOWN | PWM_GEN_MODE_NO_SYNC);

            //Set the Period (expressed in clock ticks)
            PWMGenPeriodSet(PWM0_BASE, PWM_GEN_1, PWM_PERIOD);
            //Set PWM duty-50% (Period /2)
            PWMPulseWidthSet(PWM0_BASE, PWM_OUT_2, (ui8Pwm*PWM_PERIOD)/100 );
            // Enable the PWM generator
            PWMGenEnable(PWM0_BASE, PWM_GEN_1);
            // Turn on the Output pins
            PWMOutputState(PWM0_BASE, PWM_OUT_2_BIT, true);
            break;
        case 5:
            GPIOPinConfigure(GPIO_PB5_M0PWM3);
            SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM0);
            PWMGenConfigure(PWM0_BASE, PWM_GEN_1, PWM_GEN_MODE_DOWN | PWM_GEN_MODE_NO_SYNC);

            //Set the Period (expressed in clock ticks)
            PWMGenPeriodSet(PWM0_BASE, PWM_GEN_1, PWM_PERIOD);
            //Set PWM duty-50% (Period /2)
            PWMPulseWidthSet(PWM0_BASE, PWM_OUT_3, (ui8Pwm*PWM_PERIOD)/100 );
            // Enable the PWM generator
            PWMGenEnable(PWM0_BASE, PWM_GEN_1);
            // Turn on the Output pins
            PWMOutputState(PWM0_BASE, PWM_OUT_3_BIT, true);
            break;
        case 6:
            GPIOPinConfigure(GPIO_PB6_M0PWM0);
            SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM0);
            PWMGenConfigure(PWM0_BASE, PWM_GEN_0, PWM_GEN_MODE_DOWN | PWM_GEN_MODE_NO_SYNC);

            //Set the Period (expressed in clock ticks)
            PWMGenPeriodSet(PWM0_BASE, PWM_GEN_0, PWM_PERIOD);
            //Set PWM duty-50% (Period /2)
            PWMPulseWidthSet(PWM0_BASE, PWM_OUT_0, (ui8Pwm*PWM_PERIOD)/100 );
            // Enable the PWM generator
            PWMGenEnable(PWM0_BASE, PWM_GEN_0);
            // Turn on the Output pins
            PWMOutputState(PWM0_BASE, PWM_OUT_0_BIT, true);
            break;
        case 7:
            GPIOPinConfigure(GPIO_PB7_M0PWM1);
            SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM0);
            PWMGenConfigure(PWM0_BASE, PWM_GEN_0, PWM_GEN_MODE_DOWN | PWM_GEN_MODE_NO_SYNC);

            //Set the Period (expressed in clock ticks)
            PWMGenPeriodSet(PWM0_BASE, PWM_GEN_0, PWM_PERIOD);
            //Set PWM duty-50% (Period /2)
            PWMPulseWidthSet(PWM0_BASE, PWM_OUT_1, (ui8Pwm*PWM_PERIOD)/100 );
            // Enable the PWM generator
            PWMGenEnable(PWM0_BASE, PWM_GEN_0);
            // Turn on the Output pins
            PWMOutputState(PWM0_BASE, PWM_OUT_1_BIT, true);
            break;
        default:
            ui8Error=1;
            break;
        }
    }
    break;
    case PORTC:
    {
        SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC);
        switch (ui8PinNumber) {
        case 4:
            GPIOPinConfigure(GPIO_PC4_M0PWM6);
            SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM0);
            PWMGenConfigure(PWM0_BASE, PWM_GEN_3, PWM_GEN_MODE_DOWN | PWM_GEN_MODE_NO_SYNC);

            //Set the Period (expressed in clock ticks)
            PWMGenPeriodSet(PWM0_BASE, PWM_GEN_3, PWM_PERIOD);
            //Set PWM duty-50% (Period /2)
            PWMPulseWidthSet(PWM0_BASE, PWM_OUT_6, (ui8Pwm*PWM_PERIOD)/100 );
            // Enable the PWM generator
            PWMGenEnable(PWM0_BASE, PWM_GEN_3);
            // Turn on the Output pins
            PWMOutputState(PWM0_BASE, PWM_OUT_6_BIT, true);
            break;
        case 5:
            GPIOPinConfigure(GPIO_PC5_M0PWM7);
            SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM0);
            PWMGenConfigure(PWM0_BASE, PWM_GEN_3, PWM_GEN_MODE_DOWN | PWM_GEN_MODE_NO_SYNC);

            //Set the Period (expressed in clock ticks)
            PWMGenPeriodSet(PWM0_BASE, PWM_GEN_3, PWM_PERIOD);
            //Set PWM duty-50% (Period /2)
            PWMPulseWidthSet(PWM0_BASE, PWM_OUT_7, (ui8Pwm*PWM_PERIOD)/100 );
            // Enable the PWM generator
            PWMGenEnable(PWM0_BASE, PWM_GEN_3);
            // Turn on the Output pins
            PWMOutputState(PWM0_BASE, PWM_OUT_7_BIT, true);
            break;
        default:
            ui8Error=1;
            break;
        }
    }
    break;
    case PORTD:
    {
        SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);
        switch (ui8PinNumber) {
        case 0:
            GPIOPinConfigure(GPIO_PD0_M1PWM0);
            SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM1);
            PWMGenConfigure(PWM1_BASE, PWM_GEN_0, PWM_GEN_MODE_DOWN | PWM_GEN_MODE_NO_SYNC);

            //Set the Period (expressed in clock ticks)
            PWMGenPeriodSet(PWM1_BASE, PWM_GEN_0, PWM_PERIOD);
            //Set PWM duty-50% (Period /2)
            PWMPulseWidthSet(PWM1_BASE, PWM_OUT_0, (ui8Pwm*PWM_PERIOD)/100 );
            // Enable the PWM generator
            PWMGenEnable(PWM1_BASE, PWM_GEN_0);
            // Turn on the Output pins
            PWMOutputState(PWM1_BASE, PWM_OUT_0_BIT, true);
            break;
        case 1:
            GPIOPinConfigure(GPIO_PD1_M1PWM1);
            SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM1);
            PWMGenConfigure(PWM1_BASE, PWM_GEN_0, PWM_GEN_MODE_DOWN | PWM_GEN_MODE_NO_SYNC);

            //Set the Period (expressed in clock ticks)
            PWMGenPeriodSet(PWM1_BASE, PWM_GEN_0, PWM_PERIOD);
            //Set PWM duty-50% (Period /2)
            PWMPulseWidthSet(PWM1_BASE, PWM_OUT_1, (ui8Pwm*PWM_PERIOD)/100 );
            // Enable the PWM generator
            PWMGenEnable(PWM1_BASE, PWM_GEN_0);
            // Turn on the Output pins
            PWMOutputState(PWM1_BASE, PWM_OUT_1_BIT, true);
            break;
        default:
            ui8Error=1;
            break;
        }
    }
    break;
    case PORTE:
    {
        SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
        switch (ui8PinNumber) {
        case 4:
            GPIOPinConfigure(GPIO_PE4_M0PWM4);
            SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM0);
            PWMGenConfigure(PWM0_BASE, PWM_GEN_2, PWM_GEN_MODE_DOWN | PWM_GEN_MODE_NO_SYNC);

            //Set the Period (expressed in clock ticks)
            PWMGenPeriodSet(PWM0_BASE, PWM_GEN_2, PWM_PERIOD);
            //Set PWM duty-50% (Period /2)
            PWMPulseWidthSet(PWM0_BASE, PWM_OUT_4, (ui8Pwm*PWM_PERIOD)/100 );
            // Enable the PWM generator
            PWMGenEnable(PWM0_BASE, PWM_GEN_2);
            // Turn on the Output pins
            PWMOutputState(PWM0_BASE, PWM_OUT_4_BIT, true);
            break;
        case 5:
            GPIOPinConfigure(GPIO_PE5_M0PWM5);
            SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM0);
            PWMGenConfigure(PWM0_BASE, PWM_GEN_2, PWM_GEN_MODE_DOWN | PWM_GEN_MODE_NO_SYNC);

            //Set the Period (expressed in clock ticks)
            PWMGenPeriodSet(PWM0_BASE, PWM_GEN_2, PWM_PERIOD);
            //Set PWM duty-50% (Period /2)
            PWMPulseWidthSet(PWM0_BASE, PWM_OUT_5, (ui8Pwm*PWM_PERIOD)/100 );
            // Enable the PWM generator
            PWMGenEnable(PWM0_BASE, PWM_GEN_2);
            // Turn on the Output pins
            PWMOutputState(PWM0_BASE, PWM_OUT_5_BIT, true);
            break;
        default:
            ui8Error=1;
            break;
        }
    }
    break;
    case PORTF:
    {
        SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
        switch (ui8PinNumber) {
        case 0:
            GPIOPinConfigure(GPIO_PF0_M1PWM4);
            SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM1);
            PWMGenConfigure(PWM1_BASE, PWM_GEN_2, PWM_GEN_MODE_DOWN | PWM_GEN_MODE_NO_SYNC);

            //Set the Period (expressed in clock ticks)
            PWMGenPeriodSet(PWM1_BASE, PWM_GEN_2, PWM_PERIOD);
            //Set PWM duty-50% (Period /2)
            PWMPulseWidthSet(PWM1_BASE, PWM_OUT_4, (ui8Pwm*PWM_PERIOD)/100 );
            // Enable the PWM generator
            PWMGenEnable(PWM1_BASE, PWM_GEN_2);
            // Turn on the Output pins
            PWMOutputState(PWM1_BASE, PWM_OUT_4_BIT, true);
            break;
        case 1:
            GPIOPinConfigure(GPIO_PF1_M1PWM5);
            SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM1);
            PWMGenConfigure(PWM1_BASE, PWM_GEN_2, PWM_GEN_MODE_DOWN | PWM_GEN_MODE_NO_SYNC);

            //Set the Period (expressed in clock ticks)
            PWMGenPeriodSet(PWM1_BASE, PWM_GEN_2, PWM_PERIOD);
            //Set PWM duty-50% (Period /2)
            PWMPulseWidthSet(PWM1_BASE, PWM_OUT_5, (ui8Pwm*PWM_PERIOD)/100 );
            // Enable the PWM generator
            PWMGenEnable(PWM1_BASE, PWM_GEN_2);
            // Turn on the Output pins
            PWMOutputState(PWM1_BASE, PWM_OUT_5_BIT, true);
            break;
        case 2:
            GPIOPinConfigure(GPIO_PF2_M1PWM6);
            SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM1);
            PWMGenConfigure(PWM1_BASE, PWM_GEN_3, PWM_GEN_MODE_DOWN | PWM_GEN_MODE_NO_SYNC);

            //Set the Period (expressed in clock ticks)
            PWMGenPeriodSet(PWM1_BASE, PWM_GEN_3, PWM_PERIOD);
            //Set PWM duty-50% (Period /2)
            PWMPulseWidthSet(PWM1_BASE, PWM_OUT_6, (ui8Pwm*PWM_PERIOD)/100 );
            // Enable the PWM generator
            PWMGenEnable(PWM1_BASE, PWM_GEN_3);
            // Turn on the Output pins
            PWMOutputState(PWM1_BASE, PWM_OUT_6_BIT, true);
            break;
        case 3:
            GPIOPinConfigure(GPIO_PF3_M1PWM7);
            SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM1);
            PWMGenConfigure(PWM1_BASE, PWM_GEN_3, PWM_GEN_MODE_DOWN | PWM_GEN_MODE_NO_SYNC);

            //Set the Period (expressed in clock ticks)
            PWMGenPeriodSet(PWM1_BASE, PWM_GEN_3, PWM_PERIOD);
            //Set PWM duty-50% (Period /2)
            PWMPulseWidthSet(PWM1_BASE, PWM_OUT_7, (ui8Pwm*PWM_PERIOD)/100 );
            // Enable the PWM generator
            PWMGenEnable(PWM1_BASE, PWM_GEN_3);
            // Turn on the Output pins
            PWMOutputState(PWM1_BASE, PWM_OUT_7_BIT, true);
            break;
        default:
            ui8Error=1;
            break;
        }
    }
    break;
    default:
        break;
    }
    return ui8Error;
}


void ChangeDutyCycle(uint8_t ui8PwmModule,uint8_t PwmPin,uint8_t ui8Pwm)
{
    PWMPulseWidthSet(PWM1_BASE, PWM_OUT_7, (ui8Pwm*PWM_PERIOD)/100 );
}
